package com.lumiere.app

import android.Manifest
import android.bluetooth.*
import android.bluetooth.le.*
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.*
import androidx.compose.ui.graphics.*
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.*
import androidx.core.content.ContextCompat
import kotlinx.coroutines.*
import java.util.UUID

private val Bg = Color(0xFF080B10)
private val Panel = Color(0xFF111823)
private val Cyan = Color(0xFF65D9F5)
private val Muted = Color(0xFF8996A8)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val ble = LumiereBle(this)
        setContent { LumiereApp(ble) }
    }
}

data class BleDevice(val name: String, val address: String, val rssi: Int)

class LumiereBle(private val context: Context) {
    private val manager = context.getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager
    private val adapter get() = manager.adapter
    private val scanner get() = adapter?.bluetoothLeScanner
    var devices by mutableStateOf(listOf<BleDevice>())
        private set
    var status by mutableStateOf("Not connected")
        private set
    var connectedName by mutableStateOf("")
        private set
    var services by mutableStateOf(listOf<String>())
        private set
    private var gatt: BluetoothGatt? = null
    private var scanning = false

    private val scanCallback = object : ScanCallback() {
        override fun onScanResult(callbackType: Int, result: ScanResult) {
            val d = result.device
            val item = BleDevice(d.name ?: result.scanRecord?.deviceName ?: "Unknown device", d.address, result.rssi)
            devices = (devices.filterNot { it.address == item.address } + item).sortedByDescending { it.rssi }
        }
        override fun onScanFailed(errorCode: Int) { status = "Scan failed: $errorCode"; scanning = false }
    }

    fun startScan() {
        if (Build.VERSION.SDK_INT >= 31 &&
            ContextCompat.checkSelfPermission(context, Manifest.permission.BLUETOOTH_SCAN) != PackageManager.PERMISSION_GRANTED) {
            status = "Bluetooth scan permission required"; return
        }
        if (adapter?.isEnabled != true) { status = "Bluetooth is off"; return }
        devices = emptyList()
        try {
            scanner?.startScan(scanCallback)
            scanning = true
            status = "Scanning nearby devices…"
        } catch (e: SecurityException) { status = "Permission required" }
    }

    fun stopScan() {
        try { if (scanning) scanner?.stopScan(scanCallback) } catch (_: SecurityException) {}
        scanning = false
    }

    fun connect(address: String) {
        stopScan()
        if (Build.VERSION.SDK_INT >= 31 &&
            ContextCompat.checkSelfPermission(context, Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
            status = "Bluetooth connect permission required"; return
        }
        try {
            status = "Connecting…"
            val device = adapter?.getRemoteDevice(address) ?: run { status = "Device unavailable"; return }
            gatt?.close()
            gatt = device.connectGatt(context, false, object : BluetoothGattCallback() {
                override fun onConnectionStateChange(g: BluetoothGatt, state: Int, newState: Int) {
                    if (newState == BluetoothProfile.STATE_CONNECTED) {
                        status = "Connected — discovering services"
                        g.discoverServices()
                    } else {
                        status = if (newState == BluetoothProfile.STATE_DISCONNECTED) "Disconnected" else "Connection changed"
                        services = emptyList()
                    }
                }
                override fun onServicesDiscovered(g: BluetoothGatt, statusCode: Int) {
                    services = g.services.map { s -> "${s.uuid} (${s.characteristics.size} characteristics)" }
                    status = if (statusCode == BluetoothGatt.GATT_SUCCESS) "Connected · GATT discovered" else "GATT discovery error: $statusCode"
                }
            }, BluetoothDevice.TRANSPORT_LE)
            connectedName = devices.firstOrNull { it.address == address }?.name ?: address
        } catch (e: SecurityException) { status = "Permission required" }
    }

    fun disconnect() {
        try { gatt?.disconnect(); gatt?.close() } catch (_: SecurityException) {}
        gatt = null
        connectedName = ""
        services = emptyList()
        status = "Disconnected"
    }
}

@Composable
fun LumiereApp(ble: LumiereBle) {
    var tab by remember { mutableStateOf(0) }
    var color by remember { mutableStateOf(Color(0xFF55CFFF)) }
    var brightness by remember { mutableFloatStateOf(72f) }
    var power by remember { mutableStateOf(false) }
    var showPerm by remember { mutableStateOf(false) }
    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { result ->
        if (result.values.all { it }) ble.startScan()
    }
    MaterialTheme(colorScheme = darkColorScheme(
        background = Bg, surface = Panel, primary = Cyan, onBackground = Color.White,
        onSurface = Color.White, secondary = Color(0xFF9C8BFF)
    )) {
        Column(Modifier.fillMaxSize().background(Bg)) {
            Header(power, { power = !power }, ble.status)
            Box(Modifier.weight(1f)) {
                when (tab) {
                    0 -> ColorScreen(color, { color = it }, brightness, { brightness = it }, power, { power = it })
                    1 -> EffectsScreen()
                    2 -> MusicScreen()
                    3 -> CinemaScreen()
                    else -> DevicesScreen(ble, {
                        val p = mutableListOf(Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT)
                        if (Build.VERSION.SDK_INT < 31) p.add(Manifest.permission.ACCESS_FINE_LOCATION)
                        permissionLauncher.launch(p.toTypedArray())
                    })
                }
            }
            NavigationBar(containerColor = Color(0xFF0D131C), contentColor = Muted) {
                listOf("COLOR", "EFFECTS", "MUSIC", "CINEMA", "DEVICES").forEachIndexed { i, label ->
                    NavigationBarItem(selected = tab == i, onClick = { tab = i },
                        icon = { Icon(listOf(Icons.Default.Palette, Icons.Default.AutoAwesome, Icons.Default.GraphicEq, Icons.Default.Movie, Icons.Default.Bluetooth)[i], null) },
                        label = { Text(label, fontSize = 9.sp, fontWeight = FontWeight.SemiBold) },
                        colors = NavigationBarItemDefaults.colors(selectedIconColor = Cyan, selectedTextColor = Cyan,
                            indicatorColor = Color(0xFF18303B), unselectedIconColor = Muted, unselectedTextColor = Muted))
                }
            }
        }
    }
}

@Composable
fun Header(power: Boolean, onPower: () -> Unit, status: String) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 22.dp, vertical = 18.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text("LUMIÈRE", fontSize = 21.sp, letterSpacing = 4.sp, fontWeight = FontWeight.Light, color = Color.White)
            Text(status.uppercase(), fontSize = 9.sp, letterSpacing = 1.4.sp, color = Muted, maxLines = 1)
        }
        Surface(onClick = onPower, shape = CircleShape, color = if (power) Color(0xFF163744) else Panel,
            border = BorderStroke(1.dp, if (power) Cyan.copy(.6f) else Color(0xFF263241))) {
            Row(Modifier.padding(horizontal = 14.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.PowerSettingsNew, null, tint = if (power) Cyan else Muted, modifier = Modifier.size(17.dp))
                Spacer(Modifier.width(7.dp))
                Text(if (power) "ON" else "POWER", fontSize = 10.sp, letterSpacing = 1.sp, color = if (power) Cyan else Color.White)
            }
        }
    }
}

@Composable
fun SectionTitle(kicker: String, title: String, subtitle: String) {
    Column(Modifier.padding(bottom = 18.dp)) {
        Text(kicker, color = Cyan, fontSize = 10.sp, letterSpacing = 2.5.sp, fontWeight = FontWeight.Bold)
        Text(title, color = Color.White, fontSize = 29.sp, fontWeight = FontWeight.Light)
        Text(subtitle, color = Muted, fontSize = 12.sp)
    }
}

@Composable
fun ColorScreen(color: Color, onColor: (Color) -> Unit, brightness: Float, onBrightness: (Float) -> Unit, power: Boolean, onPower: (Boolean) -> Unit) {
    val presets = listOf(Color.Red, Color(0xFFFF4F9A), Color.Blue, Color.Cyan, Color.Green, Color.Yellow, Color.White, Color(0xFF9B59FF), Color(0xFFFF8A32), Color(0xFF28D6B0))
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 22.dp, vertical = 12.dp)) {
        SectionTitle("LIGHTING CONTROL", "Color studio", "Shape the atmosphere.")
        Box(Modifier.fillMaxWidth().height(270.dp), contentAlignment = Alignment.Center) {
            Box(Modifier.size(244.dp).background(Brush.sweepGradient(presets + presets.first()), CircleShape).padding(13.dp)
                .background(Bg, CircleShape).padding(14.dp).background(Brush.radialGradient(listOf(color.copy(.38f), Bg)), CircleShape),
                contentAlignment = Alignment.Center) {
                Box(Modifier.size(104.dp).background(Brush.radialGradient(listOf(color, color.copy(.25f))), CircleShape)
                    .border(1.dp, Color.White.copy(.35f), CircleShape))
            }
            Text("TAP A PRESET BELOW", Modifier.align(Alignment.BottomCenter).padding(bottom = 4.dp), color = Muted, fontSize = 9.sp, letterSpacing = 1.5.sp)
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("QUICK COLORS", color = Muted, fontSize = 10.sp, letterSpacing = 1.5.sp)
            Text("#%02X%02X%02X".format((color.red*255).toInt(), (color.green*255).toInt(), (color.blue*255).toInt()), color = Color.White, fontSize = 11.sp)
        }
        Spacer(Modifier.height(13.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            presets.forEach { c -> Box(Modifier.size(27.dp).clip(CircleShape).background(c)
                .border(if (c == color) 2.dp else 0.dp, Color.White, CircleShape).clickable { onColor(c) }) }
        }
        Spacer(Modifier.height(26.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("BRIGHTNESS", color = Muted, fontSize = 10.sp, letterSpacing = 1.5.sp)
            Text("${brightness.toInt()}%", color = Color.White, fontSize = 12.sp)
        }
        Slider(value = brightness, onValueChange = onBrightness, valueRange = 0f..100f, colors = SliderDefaults.colors(thumbColor = Cyan, activeTrackColor = Cyan, inactiveTrackColor = Panel))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("RGB  ${ (color.red*255).toInt() } · ${(color.green*255).toInt()} · ${(color.blue*255).toInt()}", color = Muted, fontSize = 11.sp)
            Text("HEX", color = Muted, fontSize = 10.sp)
        }
        Spacer(Modifier.height(18.dp))
        Text("DEVICE COMMANDS ARE LOCKED UNTIL THE LEDNETWF PACKET FORMAT IS VERIFIED.", color = Color(0xFFE5B96C), fontSize = 9.sp, letterSpacing = 1.sp)
        Spacer(Modifier.height(20.dp))
    }
}

@Composable
fun PremiumCard(title: String, desc: String, trailing: String = "OPEN", onClick: () -> Unit = {}) {
    Surface(onClick = onClick, color = Panel, shape = RoundedCornerShape(18.dp), border = BorderStroke(1.dp, Color(0xFF202B39))) {
        Row(Modifier.fillMaxWidth().padding(17.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) { Text(title, color = Color.White, fontWeight = FontWeight.Medium, fontSize = 15.sp); Text(desc, color = Muted, fontSize = 11.sp) }
            Text(trailing, color = Cyan, fontSize = 9.sp, letterSpacing = 1.sp)
        }
    }
}

@Composable
fun EffectsScreen() {
    val effects = listOf("Rainbow Flow", "Rainbow Cycle", "Color Wave", "Color Chase", "Smooth Gradient", "Fire", "Candle", "Ocean", "Aurora", "Sunset", "Northern Lights", "Neon Pulse", "Breathing", "Strobe", "Meteor", "Twinkle", "Party Mode", "Disco", "Police Lights", "Cyberpunk", "Relax", "Romantic", "Focus", "Night Mode")
    var selected by remember { mutableStateOf("Aurora") }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(22.dp)) {
        SectionTitle("MOTION & ATMOSPHERE", "Light effects", "A curated library of light signatures.")
        effects.forEach { e ->
            PremiumCard(e, if (e == selected) "Selected locally · hardware protocol pending" else "Effect preset", if (e == selected) "SELECTED" else "›") { selected = e }
            Spacer(Modifier.height(8.dp))
        }
    }
}

@Composable
fun MusicScreen() {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(22.dp)) {
        SectionTitle("SOUND REACTIVE", "Music studio", "Turn sound into atmosphere.")
        Box(Modifier.fillMaxWidth().height(170.dp).clip(RoundedCornerShape(22.dp)).background(Brush.linearGradient(listOf(Color(0xFF142D3C), Color(0xFF17142C)))), contentAlignment = Alignment.Center) {
            Row(horizontalArrangement = Arrangement.spacedBy(5.dp), verticalAlignment = Alignment.CenterVertically) {
                (listOf(25,55,90,45,115,70,135,65,105,42,80,30,60,95,35)).forEach { h ->
                    Box(Modifier.width(5.dp).height(h.dp).clip(RoundedCornerShape(5.dp)).background(Cyan.copy(.8f)))
                }
            }
        }
        Spacer(Modifier.height(18.dp))
        PremiumCard("Microphone input", "Audio capture and frequency analysis", "COMING")
        Spacer(Modifier.height(10.dp))
        PremiumCard("Local music library", "Choose and play audio files", "COMING")
        Spacer(Modifier.height(10.dp))
        Text("Microphone processing and LED synchronization will be enabled in a later engine milestone.", color = Muted, fontSize = 11.sp)
    }
}

@Composable
fun CinemaScreen() {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(22.dp)) {
        SectionTitle("IMMERSIVE LIGHT", "Cinema mode", "Build a scene around your screen.")
        Box(Modifier.fillMaxWidth().height(220.dp).clip(RoundedCornerShape(24.dp)).background(Brush.verticalGradient(listOf(Color(0xFF182B40), Color(0xFF090D14)))), contentAlignment = Alignment.Center) {
            Box(Modifier.fillMaxWidth(.72f).height(115.dp).clip(RoundedCornerShape(10.dp)).background(Color(0xFF05070A)).border(1.dp, Color(0xFF607A94), RoundedCornerShape(10.dp)))
            Text("AMBIENT SPACE", Modifier.align(Alignment.BottomCenter).padding(15.dp), color = Muted, fontSize = 9.sp, letterSpacing = 2.sp)
        }
        Spacer(Modifier.height(18.dp))
        listOf("Cinema", "Horror", "Sci-Fi", "Gaming", "Relax", "Warm Evening", "Cold Atmosphere", "Sunset").forEach {
            PremiumCard(it, "Atmosphere preset · local preview", "›")
            Spacer(Modifier.height(8.dp))
        }
    }
}

@Composable
fun DevicesScreen(ble: LumiereBle, requestPermissions: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(22.dp)) {
        SectionTitle("HARDWARE & CONNECTION", "Devices", "Discover and manage BLE controllers.")
        Surface(color = Panel, shape = RoundedCornerShape(20.dp), border = BorderStroke(1.dp, Color(0xFF263342))) {
            Column(Modifier.padding(17.dp)) {
                Text("ACTIVE CONNECTION", color = Muted, fontSize = 9.sp, letterSpacing = 1.5.sp)
                Spacer(Modifier.height(6.dp))
                Text(ble.connectedName.ifBlank { "No controller connected" }, color = Color.White, fontSize = 16.sp)
                Text(ble.status, color = Cyan, fontSize = 11.sp)
                Spacer(Modifier.height(12.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = requestPermissions, colors = ButtonDefaults.buttonColors(containerColor = Cyan, contentColor = Bg)) { Text("SCAN BLE") }
                    OutlinedButton(onClick = { ble.disconnect() }) { Text("DISCONNECT") }
                }
                Text("Known target: LEDnetWF0200084C89D6", color = Muted, fontSize = 10.sp)
            }
        }
        Spacer(Modifier.height(18.dp))
        Text("NEARBY DEVICES", color = Muted, fontSize = 10.sp, letterSpacing = 1.5.sp)
        LazyColumn(Modifier.weight(1f)) {
            items(ble.devices) { d ->
                PremiumCard(d.name, "${d.address}  ·  RSSI ${d.rssi} dBm", "CONNECT") { ble.connect(d.address) }
                Spacer(Modifier.height(8.dp))
            }
        }
        if (ble.services.isNotEmpty()) {
            Text("DISCOVERED GATT SERVICES", color = Cyan, fontSize = 10.sp)
            ble.services.forEach { Text(it, color = Muted, fontSize = 9.sp) }
        }
    }
}
