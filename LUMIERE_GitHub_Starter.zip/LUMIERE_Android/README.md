# LUMIÈRE — Android starter project

This is the first native Android implementation milestone:
- Premium dark Compose interface with COLOR / EFFECTS / MUSIC / CINEMA / DEVICES navigation.
- BLE permission declarations for Android 12+ and legacy Android.
- BLE scanning, connection, GATT service discovery, disconnect handling.
- Recognizes and displays real nearby BLE devices and discovered services.

## Open
Open this folder in Android Studio (Ladybug or newer), allow Gradle sync, then Run on an Android phone.

## Hardware protocol status
The target controller was identified from user-provided diagnostics as `LEDnetWF0200084C89D6`, address `E4:98:BB:4C:89:D6`, with services `FE00` and `FFFF`; characteristics include `FF22`, `FF11`, `FF02`, `FF01`.

The project intentionally does NOT send guessed LED commands. The `FFFF/FF01/FF02` protocol family has public reverse-engineering references, but packet compatibility must be validated against this exact controller/firmware before enabling POWER, color, brightness, or effects. UI presets currently update local preview only.

## Next milestones
1. Validate exact packet frames for this hardware.
2. Add a serialized GATT command queue and device driver.
3. Bind COLOR / POWER / brightness to confirmed packets.
4. Implement effects, audio, camera, scenes and scheduling with truthful capability gating.

See `app/src/main/java/com/lumiere/app/MainActivity.kt` for the first implementation.
